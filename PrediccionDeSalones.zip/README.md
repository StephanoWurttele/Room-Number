# Introduction

Programa para calcular probabilidad de alumnos de aprobar de acuerdo a su historial de notas. El resultado se expone en un archivo .xlsx.

# Librerias

- [xlsxwriter](https://xlsxwriter.readthedocs.io/getting_started.html).
- [csv](https://docs.python.org/3/library/csv.html).
- random
